%s=[1,2];
%t=[2,3];
G=graph([1,2],[2,3]);
%G=graph(s,t);
plot(G);
title('undirected graph');