G=digraph([1,2],[2,3]);

plot(G);
title('directed graph');