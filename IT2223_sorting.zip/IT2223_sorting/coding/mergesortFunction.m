function sortedArray = mergeSort(arr)
    n = length(arr);
    
    if n <= 1
        sortedArray = arr; % Base case: return if array has 1 or no elements
        return;
    end
    
    mid = floor(n / 2); % Find the middle index
    leftHalf = mergeSort(arr(1:mid)); % Recursively sort left half
    rightHalf = mergeSort(arr(mid+1:end)); % Recursively sort right half
    
    sortedArray = merge(leftHalf, rightHalf); % Merge sorted halves
end

function mergedArray = merge(leftHalf, rightHalf)
    i = 1; 
    j = 1;
    mergedArray = []; % Initialize merged array
    
    % Merge elements in sorted order
    while i <= numel(leftHalf) && j <= numel(rightHalf)
        if leftHalf(i) <= rightHalf(j)
            mergedArray = [mergedArray, leftHalf(i)];
            i = i + 1;
        else
            mergedArray = [mergedArray, rightHalf(j)];
            j = j + 1;
        end
    end
    
    % Append remaining elements
    mergedArray = [mergedArray, leftHalf(i:end), rightHalf(j:end)];
end

% Test the Merge Sort function
arr = [7, 4, 10, 8, 3, 1]; % Example input array
sortedArr = mergeSort(arr);
disp('Sorted Array:');
disp(sortedArr);
