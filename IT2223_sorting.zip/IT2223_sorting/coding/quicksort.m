function sortedArray = quickSort(arr)
    if numel(arr) <= 1
        sortedArray = arr; % Base case: return if array has 1 or no elements
        return;
    end
    
    pivot = arr(end); % Choose the last element as pivot
    leftHalf = arr(arr < pivot); % Elements less than pivot
    rightHalf = arr(arr > pivot); % Elements greater than pivot
    equalPivot = arr(arr == pivot); % Elements equal to pivot
    
    % Recursively sort left and right halves
    sortedArray = [quickSort(leftHalf), equalPivot, quickSort(rightHalf)];
end

% Test the QuickSort function
arr = [5, 2, 1, 8, 7]; % Example input array
sortedArr = quickSort(arr);
disp('Sorted Array:');
disp(sortedArr);
