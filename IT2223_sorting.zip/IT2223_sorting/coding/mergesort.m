arr = [7, 4, 10, 8, 3, 1]; 
n = length(arr);

% Iterative Merge Sort without 'width'
for size = 1:n
    for i = 1:2*size:n
        mid = min(i + size - 1, n);  % Middle index
        rightEnd = min(i + 2*size - 1, n);  % Rightmost index
        
        % Extract left and right halves
        leftHalf = arr(i:mid);
        rightHalf = arr(mid+1:rightEnd);
        mergedArray = [];
        
        j = 1; k = 1;
        while j <= numel(leftHalf) && k <= numel(rightHalf)
            if leftHalf(j) <= rightHalf(k)
                mergedArray = [mergedArray, leftHalf(j)];
                j = j + 1;
            else
                mergedArray = [mergedArray, rightHalf(k)];
                k = k + 1;
            end
        end
        
        % Append remaining elements
        mergedArray = [mergedArray, leftHalf(j:end), rightHalf(k:end)];
        
        % Update original array with merged result
        arr(i:rightEnd) = mergedArray;
    end
end

disp('Sorted Array:');
disp(arr);
