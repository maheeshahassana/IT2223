% Distance matrix
DIST = [0 10 15 20;
        10 0 35 25;
        15 35 0 30;
        20 25 30 0];

% Generate all possible routes excluding the starting city (1)
allPerms = perms([2 3 4]); 

numRoutes = size(allPerms, 1); % Number of possible routes
minCost = inf; % Initialize minimum cost
bestRoute = []; % Store best route

% Iterate over all permutations
for i = 1:numRoutes
    route = [1 allPerms(i, :) 1]; % Start at city 1 and return to city 1
    cost = 0;
    
    % Calculate the total cost of current route
    for j = 1:length(route)-1
        cost = cost + DIST(route(j), route(j+1));
    end
    
    % Update minimum cost and best route
    if cost < minCost
        minCost = cost;
        bestRoute = route;
    end
end

% Display results
fprintf('Minimum cost for TSP: %d\n', minCost);
fprintf('Best Route: ');
disp(bestRoute);
