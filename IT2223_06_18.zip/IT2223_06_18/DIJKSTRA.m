adjMatrix = [ 
    0 2 0 1 0 ; 
    2 0 4 3 0 ; 
    0 4 0 0 6 ; 
    1 3 0 0 5 ; 
    0 0 6 5 0 ; 
    
];

%G = graph(adjMatrix); % Create the graph
%plot(G, 'Layout', 'force'); % Visualize the graph
%title('Dijkstra Algorithm Graph');

n=size(adjMatrix,1);
for i=1:n
    for j=1:n
        if i ~=j && adjMatrix(i,j)==0
            adjMatrix(i,j)=Inf;
        end
    end
end

startnode=1;
visited=false(1,n);
distance=Inf(1,n);
distance(startnode)=0;

for i=1:n
    minDist=Inf;
    u=-1;
    for j=1:n
        if ~visited(j) && distance(j)<minDist
            minDist=distance(j);
            u=j;
        end
    end
    if u==-1
        break;
    end

    visited(u)=true;

    for v=1:n
        if ~visited(v)&&adjMatrix(u,v) ~=Inf
            if distance(u)+adjMatrix(u,v)<distance(v)
                distance(v)=distance(u)+adjMatrix(u,v);
            end
        end
    end
end
fprintf('shortest distances from the source:\n');
for i=1:n
    fprintf('vertex %d:%d\n',i,distance(i));
end
