clc; clear;

% Number of vertices
V = 5;

% Edge list: [source destination weight]
edges = [
    1 2 1;
    1 3 3;
    2 3 1;
    2 4 6;
    3 4 4;
    3 5 2;
    4 5 5
];

% BUBBLE SORT: Sort edges by ascending weight
n = size(edges, 1);
for i = 1:n-1
    for j = 1:n-i
        if edges(j, 3) > edges(j+1, 3)
            temp = edges(j, :);
            edges(j, :) = edges(j+1, :);
            edges(j+1, :) = temp;
        end
    end
end

% Initialize Union-Find structure
parent = 1:V;

% Find function
function root = find_parent(p, i)
    while p(i) ~= i
        i = p(i);
    end
    root = i;
end

% Union function
function p = union_sets(p, a, b)
    ra = find_parent(p, a);
    rb = find_parent(p, b);
    p(ra) = rb;
end

% Kruskal’s main loop
mst = [];
for i = 1:n
    u = edges(i, 1);
    v = edges(i, 2);
    w = edges(i, 3);
    
    set_u = find_parent(parent, u);
    set_v = find_parent(parent, v);
    
    if set_u ~= set_v
        mst = [mst; u, v, w];
        parent = union_sets(parent, set_u, set_v);
    end
end

disp('Edges in the Minimum Spanning Tree:');
disp(mst);

% 📈 Plotting the Minimum Spanning Tree
G = graph(mst(:,1), mst(:,2), mst(:,3));
figure;
plot(G, 'EdgeLabel', G.Edges.Weight, 'LineWidth', 1.5);
title('Minimum Spanning Tree using Kruskal''s Algorithm');
