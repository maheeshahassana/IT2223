

% Input: weights, values, and knapsack capacity
weights = [10, 20, 30];
values = [60, 100, 120];
capacity = 50;

% Call the function
maxProfit = fractional_knapsack(weights, values, capacity);

% Display result
fprintf('Maximum Profit (Fractional Knapsack): %.2f\n', maxProfit);

% --- Function Definition ---
function maxProfit = fractional_knapsack(weights, values, capacity)
    n = length(weights);

    % Step 1: Compute value-to-weight ratio
    ratio = values ./ weights;

    % Step 2: Combine data into a single matrix: [weight, value, ratio]
    items = [weights(:), values(:), ratio(:)];

    % Step 3: Sort by ratio in descending order (greedy strategy)
    items = sortrows(items, -3);

    % Step 4: Initialize profit
    maxProfit = 0;

    % Step 5: Greedily fill the knapsack
    for i = 1:n
        weight = items(i, 1);
        value = items(i, 2);
        r = items(i, 3);

        if capacity >= weight
            maxProfit = maxProfit + value;
            capacity = capacity - weight;
        else
            maxProfit = maxProfit + capacity * r;
            break;
        end
    end
end
