

% Number of nodes
n = 4;

% Define start and end node arrays (edges: undirected)
start_nodes = [1, 1, 1, 2, 3];
end_nodes   = [2, 3, 4, 4, 4];

% Initialize degree array
degree = zeros(1, n);

% Loop through each edge
for i = 1:length(start_nodes)
    u = start_nodes(i);
    v = end_nodes(i);

    % Increment for both nodes since the graph is undirected
    degree(u) = degree(u) + 1;
    degree(v) = degree(v) + 1;
end

% Display node degrees
fprintf('Node\tDegree\n');
for i = 1:n
    fprintf('%d\t%d\n', i, degree(i));
end
