% Kruskal's Algorithm in MATLAB

% Input: Graph with vertices and weighted edges
% Define number of vertices and edge list as [source, destination, weight]
V = 5;

edges = [%[from_node, to_node, weight]
    1 2 1;
    1 3 3;
    2 3 1;
    2 4 6;
    3 4 4;
    3 5 2;
    4 5 5
];

% Sort edges by ascending weight
edges = sortrows(edges, 3);

% Create parent array for Union-Find
parent = 1:V;

% Find function for Union-Find
function root = find_parent(parent, i)
    while parent(i) ~= i
        i = parent(i);
    end
    root = i;
end

% Union function for Union-Find
function parent = union(parent, x, y)
    xroot = find_parent(parent, x);
    yroot = find_parent(parent, y);
    parent(xroot) = yroot;
end

% Kruskal's Algorithm
mst = [];
for i = 1:size(edges,1)
    u = edges(i,1);
    v = edges(i,2);
    w = edges(i,3);
    
    set_u = find_parent(parent, u);
    set_v = find_parent(parent, v);
    
    if set_u ~= set_v
        mst = [mst; u, v, w];
        parent = union(parent, set_u, set_v);
    end
end

disp('Edges in the Minimum Spanning Tree:');
disp(mst);
