clc; clear;

n = 4;
edges = [
    1 2 1;
    1 3 3;
    1 4 2;
    2 4 4;
    3 4 5
];

numEdges = size(edges, 1);

% Bubble Sort edges by weight
for i = 1:numEdges - 1
    for j = 1:numEdges - i
        if edges(j, 3) > edges(j + 1, 3)
            temp = edges(j, :);
            edges(j, :) = edges(j + 1, :);
            edges(j + 1, :) = temp;
        end
    end
end

% Initialize MST adjacency list, MST edge list, and total weight
MST_adj = cell(n, 1);
mst = [];
totalweight = 0;

% DFS to check for cycle
function found = dfs(current, target, visited, MST_adj)
    if current == target
        found = true;
        return;
    end
    visited(current) = true;
    found = false;
    neighbors = MST_adj{current};
    for k = 1:length(neighbors)
        neigh = neighbors(k);
        if ~visited(neigh)
            found = dfs(neigh, target, visited, MST_adj);
            if found
                return;
            end
        end
    end
end

% Main loop to build MST
for i = 1:numEdges
    u = edges(i, 1);
    v = edges(i, 2);
    w = edges(i, 3);

    visited = false(1, n);
    if isempty(MST_adj{u})
        connected = false;
    else
        connected = dfs(u, v, visited, MST_adj);
    end

    if ~connected
        mst = [mst; u v w];
        totalweight = totalweight + w;

        MST_adj{u} = [MST_adj{u} v];
        MST_adj{v} = [MST_adj{v} u];
    end
end

% Display MST results
disp('Edges in MST:');
disp('node1  node2  weight');
disp(mst);
fprintf('Total weight = %d\n', totalweight);

G_mst=graph(mst(:,1),mst(:,2),mst(:,3));
figure;
plot(G_mst,'EdgeLabel',G_mst.Edges.Weight);
title('minimun spanning tree');