

% Nodes and edges
n = 5;  % number of nodes
start_nodes = [1, 1, 2, 2, 3];
end_nodes   = [2, 3, 4, 5, 4];

% Source and target nodes
source = 1;
target = 5;

% Step 1: Build adjacency list
adj = cell(n,1);
for i = 1:length(start_nodes)
    u = start_nodes(i);
    v = end_nodes(i);
    adj{u} = [adj{u}, v];
    adj{v} = [adj{v}, u];  % because undirected
end

% Step 2: BFS for shortest path
visited = false(1,n);
prev = zeros(1,n);  % to reconstruct path
queue = source;
visited(source) = true;

while ~isempty(queue)
    current = queue(1);
    queue(1) = [];

    for neighbor = adj{current}
        if ~visited(neighbor)
            visited(neighbor) = true;
            prev(neighbor) = current;
            queue(end+1) = neighbor;

            if neighbor == target
                break;
            end
        end
    end
end

% Step 3: Reconstruct the path
path = target;
while path(1) ~= source && prev(path(1)) ~= 0
    path = [prev(path(1)), path];
end

% Display result
if path(1) == source
    fprintf('Shortest path from %d to %d:\n', source, target);
    disp(path);
    fprintf('Number of edges: %d\n', length(path)-1);
else
    fprintf('No path found from %d to %d.\n', source, target);
end
