function dfs_tree(adjList, node, visited)
    if isKey(visited, node)
        return;
    end
    
    fprintf('%s ', node); % Process the node
    visited(node) = true; % Mark as visited
    
    % Recursively visit neighbors
    if isKey(adjList, node)
        neighbors = adjList(node);
        for i = 1:length(neighbors)
            dfs_tree(adjList, neighbors{i}, visited);
        end
    end
end

% Define nodes and edges
nodes = {'A', 'B', 'C', 'D', 'E', 'F', 'G'};
s = [1 1 2 2 3 3]; % Source indices
t = [2 3 4 5 6 7]; % Target indices

% Create adjacency list
adjList = containers.Map('KeyType', 'char', 'ValueType', 'any');
for i = 1:length(nodes)
    adjList(nodes{i}) = {};
end
for i = 1:length(s)
    if isKey(adjList, nodes{s(i)})
        neighbors = adjList(nodes{s(i)});
        neighbors{end+1} = nodes{t(i)};
        adjList(nodes{s(i)}) = neighbors;
    end
end

% Run DFS
fprintf('DFS Traversal: ');
visited = containers.Map('KeyType', 'char', 'ValueType', 'logical');
dfs_tree(adjList, 'A', visited);
fprintf('\n'); % New line at end

% Create directed graph for visualization
G = digraph(s, t, [], nodes);

% Plot the graph
figure;
plot(G, 'Layout', 'layered', 'NodeLabel', nodes);
title('Graph Representation of DFS');
