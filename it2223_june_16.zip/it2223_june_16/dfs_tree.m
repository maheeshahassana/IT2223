% Define nodes and edges
nodes = {'A', 'B', 'C', 'D', 'E', 'F', 'G'};
s = [1 1 2 2 3 3]; % Source indices
t = [2 3 4 5 6 7]; % Target indices

% Create directed graph
G = digraph(s, t, [], nodes);

% Plot the graph
figure;
plot(G, 'Layout', 'layered');
title('Tree Structure');

% Perform Depth-First Search (DFS) from node 'A'
startNode = 'A';
dfs_order = dfsearch(G, startNode);

% Display DFS traversal order
fprintf('DFS Traversal Order: %s\n', strjoin(dfs_order, ' → '));
