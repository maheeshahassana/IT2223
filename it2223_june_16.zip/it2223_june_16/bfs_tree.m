% Define nodes and edges
nodes = {'A', 'B', 'C', 'D', 'E', 'F', 'G'};
s = [1 1 2 2 3 3]; % Source indices
t = [2 3 4 5 6 7]; % Target indices

% Create directed graph
G = digraph(s, t, [], nodes);

% Plot the graph
figure;
plot(G, 'Layout', 'layered');
title('Tree Structure');

% Perform Breadth-First Search (BFS) from node 'A'
startNode = 'A';
bfs_order = bfsearch(G, startNode);

% Display BFS traversal order
fprintf('BFS Traversal Order: %s\n', strjoin(bfs_order, ' → '));
