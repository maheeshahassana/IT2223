function bfs_tree(adjList, startNode)
    queue = {startNode}; % Initialize queue with the start node
    visited = containers.Map('KeyType', 'char', 'ValueType', 'logical'); % Track visited nodes
    
    % Mark the start node as visited
    visited(startNode) = true;
    
    while ~isempty(queue)
        node = queue{1}; % Get the front node
        queue(1) = []; % Remove the front node
        fprintf('%s ', node); % Process the node
        
        % Visit neighbors
        if isKey(adjList, node)
            neighbors = adjList(node);
            for i = 1:length(neighbors)
                neighbor = neighbors{i};
                if ~isKey(visited, neighbor)
                    visited(neighbor) = true;
                    queue{end+1} = neighbor; % Add to queue
                end
            end
        end
    end
    fprintf('\n'); % New line at end
end

% Define nodes and edges
nodes = {'A', 'B', 'C', 'D', 'E', 'F', 'G'};
s = [1 1 2 2 3 3]; % Source indices
t = [2 3 4 5 6 7]; % Target indices

% Create adjacency list
adjList = containers.Map('KeyType', 'char', 'ValueType', 'any');
for i = 1:length(nodes)
    adjList(nodes{i}) = {};
end
for i = 1:length(s)
    if isKey(adjList, nodes{s(i)})
        neighbors = adjList(nodes{s(i)});
        neighbors{end+1} = nodes{t(i)};
        adjList(nodes{s(i)}) = neighbors;
    end
end

% Run BFS
fprintf('BFS Traversal: ');
bfs_tree(adjList, 'A');

% Create directed graph for visualization
G = digraph(s, t, [], nodes);

% Plot the graph
figure;
plot(G, 'Layout', 'layered', 'NodeLabel', nodes);
title('Graph Representation of BFS');
