array=1:1000;

target = 900;

n = length(array);
tic;
found = false; % Flag to track if the target is found



for i = 1:n
    if array(i) == target
        fprintf('The target index is %d\n', i);
        found = true; % Mark as found
        break; % Exit the loop
    end
end

if ~found
    fprintf('The target is not found\n');
end

elapsedTime=toc;
fprintf('elapsed time:%fseconds\n',elapsedTime);
toc;

    left = 1;
right = length(array);
tic;
while left <= right
    mid = floor((left + right) / 2);
    
    if array(mid) == target
        fprintf('The target index is %d\n', mid);
        found = true;
        break;
    elseif array(mid) < target
        left = mid + 1; % Search in right half
    else
        right = mid - 1; % Search in left half
    end
end

if ~found
    fprintf('The target is not found\n');
end

elapsedTime = toc; % Stop timer
fprintf('Elapsed time: %f seconds\n', elapsedTime);
toc;