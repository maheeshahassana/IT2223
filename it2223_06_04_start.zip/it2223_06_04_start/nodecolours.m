s=[1 1 2 3 4];
t=[2 3 4 4 5];

G=graph(s,t);

nodeColors=[
    1 0 0;%RED
    0 1 0;%GREEN
    0 0 1;%BLUE
    1 1 0;%YELLOW
    1 0 1;%MEGENTA 
    ];
plot(G,'NodeColor',nodeColors,'LineWidth',1.5);

