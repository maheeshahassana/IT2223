A=[0 1 0;
   1 0 1;
   0 1 0];

plot(A);
title('adjacency graph');